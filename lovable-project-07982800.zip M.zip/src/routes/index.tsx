import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Phone, MessageCircle, Search, MapPin, Bed, Bath, Ruler, CheckCircle2, ArrowRight } from "lucide-react";

import logo from "@/assets/mughal-logo.png";
import prop1 from "@/assets/prop-1.jpg";
import prop2 from "@/assets/prop-2.jpg";
import prop3 from "@/assets/prop-3.jpg";
import prop4 from "@/assets/prop-4.jpg";
import prop5 from "@/assets/prop-5.jpg";
import prop6 from "@/assets/prop-6.jpg";
import prop7 from "@/assets/prop-7.jpg";
import prop8 from "@/assets/prop-8.jpg";
import prop9 from "@/assets/prop-9.jpg";
import prop10 from "@/assets/prop-10.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mughal Real Estate | Premium Properties in Pakistan" },
      {
        name: "description",
        content:
          "Mughal Real Estate — buy and sell premium houses, apartments, plots and commercial properties in Karachi, Lahore and Islamabad. Call or WhatsApp us today.",
      },
      { property: "og:title", content: "Mughal Real Estate | Premium Properties in Pakistan" },
      {
        property: "og:description",
        content:
          "Premium houses, apartments, plots and commercial properties in Karachi, Lahore and Islamabad.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const PHONE_DISPLAY = "+92 300 1234567";
const PHONE_TEL = "tel:+923001234567";
const WHATSAPP_URL =
  "https://wa.me/923001234567?text=Hello%20Mughal%20Real%20Estate%2C%20I%27m%20interested%20in%20a%20property.";

type Property = {
  name: string;
  price: string;
  location: string;
  type: string;
  image: string;
  beds: number;
  baths: number;
  area: string;
};

const PROPERTIES: Property[] = [
  { name: "Signature Modern Villa", price: "PKR 85,000,000", location: "DHA Phase 6, Karachi", type: "Villa", image: prop1, beds: 6, baths: 7, area: "1 Kanal" },
  { name: "Classic Family House", price: "PKR 45,000,000", location: "Bahria Town, Karachi", type: "House", image: prop2, beds: 5, baths: 6, area: "500 sq yd" },
  { name: "Skyline Residence Apartment", price: "PKR 28,000,000", location: "Gulberg III, Lahore", type: "Apartment", image: prop3, beds: 3, baths: 3, area: "2,100 sq ft" },
  { name: "Grand Bungalow with Lawn", price: "PKR 120,000,000", location: "DHA Phase 8, Lahore", type: "Villa", image: prop4, beds: 7, baths: 8, area: "2 Kanal" },
  { name: "Blue Area Commercial Tower", price: "PKR 250,000,000", location: "Blue Area, Islamabad", type: "Commercial", image: prop5, beds: 0, baths: 4, area: "12,000 sq ft" },
  { name: "Park-Facing Corner Plot", price: "PKR 15,000,000", location: "Bahria Enclave, Islamabad", type: "Plot", image: prop6, beds: 0, baths: 0, area: "10 Marla" },
  { name: "Ocean View Penthouse", price: "PKR 95,000,000", location: "Clifton Block 2, Karachi", type: "Apartment", image: prop7, beds: 4, baths: 5, area: "4,500 sq ft" },
  { name: "Contemporary Smart House", price: "PKR 65,000,000", location: "Gulberg Greens, Islamabad", type: "House", image: prop8, beds: 5, baths: 6, area: "10 Marla" },
  { name: "Luxury Pool Farmhouse", price: "PKR 55,000,000", location: "Bahria Orchard, Lahore", type: "Farmhouse", image: prop9, beds: 6, baths: 6, area: "8 Kanal" },
  { name: "Hillside Garden Apartments", price: "PKR 22,000,000", location: "E-11, Islamabad", type: "Apartment", image: prop10, beds: 2, baths: 2, area: "1,350 sq ft" },
];

const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "Properties", href: "#properties" },
  { label: "About Us", href: "#about" },
  { label: "Contact Us", href: "#contact" },
];

function Index() {
  const [query, setQuery] = useState("");
  const [type, setType] = useState("All");

  const types = useMemo(() => ["All", ...Array.from(new Set(PROPERTIES.map((p) => p.type)))], []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return PROPERTIES.filter((p) => {
      const matchesType = type === "All" || p.type === type;
      const matchesQuery =
        !q || p.name.toLowerCase().includes(q) || p.location.toLowerCase().includes(q) || p.type.toLowerCase().includes(q);
      return matchesType && matchesQuery;
    });
  }, [query, type]);

  return (
    <div className="min-h-screen bg-background font-sans">
      <Header />
      <Hero />
      <Properties query={query} setQuery={setQuery} type={type} setType={setType} types={types} filtered={filtered} />
      <About />
      <Contact />
      <Footer />

      {/* Floating WhatsApp button */}
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] shadow-lg transition-transform hover:scale-105"
      >
        <MessageCircle className="h-7 w-7 text-white" fill="white" />
      </a>
    </div>
  );
}

function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <a href="#home" className="flex items-center gap-3">
          <img src={logo} alt="Mughal Real Estate logo" className="h-10 w-auto" />
          <span className="hidden font-display text-lg font-semibold tracking-wide sm:block">
            Mughal <span className="text-gold">Real Estate</span>
          </span>
        </a>
        <nav className="flex items-center gap-1 sm:gap-6">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded px-2 py-1 text-sm font-medium text-foreground transition-colors hover:text-gold"
            >
              {link.label}
            </a>
          ))}
        </nav>
        <a
          href={PHONE_TEL}
          className="hidden items-center gap-2 rounded border border-gold px-3 py-1.5 text-sm font-semibold text-foreground transition-colors hover:bg-gold-soft md:flex"
        >
          <Phone className="h-4 w-4 text-gold" />
          {PHONE_DISPLAY}
        </a>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="home" className="relative flex min-h-[70vh] items-center overflow-hidden">
      <img
        src={prop1}
        alt="Luxury villa"
        className="absolute inset-0 h-full w-full object-cover"
        fetchPriority="high"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/55 to-black/25" />
      <div className="relative mx-auto w-full max-w-6xl px-4 py-24">
        <p className="mb-3 text-xs font-semibold uppercase tracking-[0.3em] text-gold">
          Premium Properties Across Pakistan
        </p>
        <h1 className="max-w-2xl font-display text-4xl font-semibold leading-tight text-white sm:text-5xl md:text-6xl">
          Find Your Dream Property with Mughal Real Estate
        </h1>
        <p className="mt-4 max-w-xl text-base text-white/80 sm:text-lg">
          Handpicked houses, apartments, plots and commercial spaces in Karachi, Lahore and Islamabad — trusted
          guidance from search to handover.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a
            href="#properties"
            className="inline-flex items-center gap-2 bg-gold px-6 py-3 text-sm font-semibold text-black transition-colors hover:bg-gold/90"
          >
            Browse Properties <ArrowRight className="h-4 w-4" />
          </a>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 border border-white/40 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-white/10"
          >
            <MessageCircle className="h-4 w-4" /> WhatsApp Us
          </a>
        </div>
      </div>
    </section>
  );
}

function Properties({
  query,
  setQuery,
  type,
  setType,
  types,
  filtered,
}: {
  query: string;
  setQuery: (v: string) => void;
  type: string;
  setType: (v: string) => void;
  types: string[];
  filtered: Property[];
}) {
  return (
    <section id="properties" className="mx-auto max-w-6xl px-4 py-20">
      <div className="mb-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold">Our Listings</p>
        <h2 className="mt-2 font-display text-3xl font-semibold sm:text-4xl">Featured Properties</h2>
        <div className="gold-rule mx-auto mt-4 w-24" />
      </div>

      {/* Search */}
      <div className="mx-auto mb-10 flex max-w-3xl flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name or location..."
            className="w-full border border-input bg-card py-2.5 pl-9 pr-3 text-sm outline-none transition-colors focus:border-gold"
          />
        </div>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="border border-input bg-card px-3 py-2.5 text-sm outline-none transition-colors focus:border-gold"
        >
          {types.map((t) => (
            <option key={t} value={t}>
              {t === "All" ? "All Types" : t}
            </option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <p className="py-12 text-center text-muted-foreground">
          No properties match your search. Try a different name, location or type.
        </p>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((p) => (
            <article
              key={p.name}
              className="group flex flex-col overflow-hidden border border-border bg-card transition-shadow hover:shadow-lg"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={p.image}
                  alt={p.name}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <span className="absolute left-3 top-3 bg-black/70 px-2.5 py-1 text-xs font-semibold uppercase tracking-wide text-gold">
                  {p.type}
                </span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <h3 className="font-display text-lg font-semibold">{p.name}</h3>
                <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4 text-gold" /> {p.location}
                </p>
                <p className="mt-3 text-lg font-bold text-gold">{p.price}</p>
                <div className="mt-4 flex flex-wrap gap-4 border-t border-border pt-3 text-xs text-muted-foreground">
                  {p.beds > 0 && (
                    <span className="flex items-center gap-1">
                      <Bed className="h-4 w-4" /> {p.beds} Beds
                    </span>
                  )}
                  {p.baths > 0 && (
                    <span className="flex items-center gap-1">
                      <Bath className="h-4 w-4" /> {p.baths} Baths
                    </span>
                  )}
                  <span className="flex items-center gap-1">
                    <Ruler className="h-4 w-4" /> {p.area}
                  </span>
                </div>
                <a
                  href={`${WHATSAPP_URL}%20about%20${encodeURIComponent(p.name)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-5 inline-flex items-center justify-center gap-2 border border-gold py-2 text-sm font-semibold transition-colors hover:bg-gold-soft"
                >
                  <MessageCircle className="h-4 w-4 text-gold" /> Enquire on WhatsApp
                </a>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

function About() {
  const points = [
    "Verified listings with clear titles",
    "Transparent pricing, no hidden charges",
    "Expert guidance in Karachi, Lahore & Islamabad",
    "Dedicated support from visit to handover",
  ];
  return (
    <section id="about" className="bg-secondary py-20">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 lg:grid-cols-2">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold">About Us</p>
          <h2 className="mt-2 font-display text-3xl font-semibold sm:text-4xl">
            A Trusted Name in Pakistani Real Estate
          </h2>
          <div className="gold-rule mt-4 w-24" />
          <p className="mt-6 leading-relaxed text-muted-foreground">
            Mughal Real Estate helps families and investors buy, sell and rent properties with complete confidence.
            From luxury villas and family houses to plots and commercial spaces, we combine deep local knowledge with
            honest advice — so every deal is smooth, secure and worth your money.
          </p>
          <ul className="mt-6 space-y-3">
            {points.map((point) => (
              <li key={point} className="flex items-center gap-3 text-sm font-medium">
                <CheckCircle2 className="h-5 w-5 shrink-0 text-gold" /> {point}
              </li>
            ))}
          </ul>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <img src={prop4} alt="Luxury bungalow" loading="lazy" className="aspect-square w-full object-cover" />
          <img src={prop9} alt="Farmhouse" loading="lazy" className="mt-8 aspect-square w-full object-cover" />
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="mx-auto max-w-6xl px-4 py-20">
      <div className="mb-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold">Contact Us</p>
        <h2 className="mt-2 font-display text-3xl font-semibold sm:text-4xl">We're Here to Help</h2>
        <div className="gold-rule mx-auto mt-4 w-24" />
      </div>
      <div className="mx-auto grid max-w-4xl gap-6 sm:grid-cols-3">
        <a
          href={PHONE_TEL}
          className="flex flex-col items-center gap-3 border border-border bg-card p-8 text-center transition-colors hover:border-gold"
        >
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gold-soft">
            <Phone className="h-5 w-5 text-gold" />
          </span>
          <h3 className="font-display text-lg font-semibold">Call Us</h3>
          <p className="text-sm text-muted-foreground">{PHONE_DISPLAY}</p>
        </a>
        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center gap-3 border border-border bg-card p-8 text-center transition-colors hover:border-gold"
        >
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gold-soft">
            <MessageCircle className="h-5 w-5 text-gold" />
          </span>
          <h3 className="font-display text-lg font-semibold">WhatsApp</h3>
          <p className="text-sm text-muted-foreground">Chat with our team instantly</p>
        </a>
        <div className="flex flex-col items-center gap-3 border border-border bg-card p-8 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gold-soft">
            <MapPin className="h-5 w-5 text-gold" />
          </span>
          <h3 className="font-display text-lg font-semibold">Office</h3>
          <p className="text-sm text-muted-foreground">Main Boulevard, DHA Phase 6, Karachi</p>
        </div>
      </div>
      <p className="mt-10 text-center text-sm text-muted-foreground">
        Open Monday to Saturday, 10 AM – 8 PM. Reach out any time — we usually reply within minutes.
      </p>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-ink text-white">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-6 px-4 py-10 text-center sm:flex-row sm:justify-between sm:text-left">
        <div className="flex items-center gap-3">
          <img src={logo} alt="Mughal Real Estate logo" loading="lazy" className="h-10 w-auto bg-white p-1" />
          <div>
            <p className="font-display font-semibold">Mughal Real Estate</p>
            <p className="text-xs text-white/60">Premium properties across Pakistan</p>
          </div>
        </div>
        <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm">
          {NAV_LINKS.map((link) => (
            <a key={link.href} href={link.href} className="text-white/80 transition-colors hover:text-gold">
              {link.label}
            </a>
          ))}
        </nav>
        <a href={PHONE_TEL} className="flex items-center gap-2 text-sm text-white/80 transition-colors hover:text-gold">
          <Phone className="h-4 w-4" /> {PHONE_DISPLAY}
        </a>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-white/50">
        © {new Date().getFullYear()} Mughal Real Estate. All rights reserved.
      </div>
    </footer>
  );
}
